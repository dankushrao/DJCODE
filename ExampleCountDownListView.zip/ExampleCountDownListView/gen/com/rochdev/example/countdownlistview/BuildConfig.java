/** Automatically generated file. DO NOT MODIFY */
package com.rochdev.example.countdownlistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}