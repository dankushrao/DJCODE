/** Automatically generated file. DO NOT MODIFY */
package androidinterview.com.androidgalleryview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}