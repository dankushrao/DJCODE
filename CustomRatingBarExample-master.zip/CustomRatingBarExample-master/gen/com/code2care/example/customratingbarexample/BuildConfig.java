/** Automatically generated file. DO NOT MODIFY */
package com.code2care.example.customratingbarexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}