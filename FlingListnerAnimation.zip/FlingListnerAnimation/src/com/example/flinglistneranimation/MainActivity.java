package com.example.flinglistneranimation;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		final ImageView imageView = (ImageView) findViewById(R.id.image_view);
		imageView.setOnTouchListener(new OnFlingGestureListener() {

			@Override
			public void onTopToBottom() {
				// Your code here
				Log.d("OnFlingGestureListener", "onTopToBottom");
			}

			@Override
			public void onRightToLeft() {
				// Your code here
				Log.d("OnFlingGestureListener", "onRightToLeft");
			}

			@Override
			public void onLeftToRight() {
				// Your code here
				imageView.setBackgroundResource(R.drawable.two);
				Log.d("OnFlingGestureListener", "onLeftToRight");
			}

			@Override
			public void onBottomToTop() {
				// Your code here
				Log.d("OnFlingGestureListener", "onBottomToTop");
			}
		});
	}
}
